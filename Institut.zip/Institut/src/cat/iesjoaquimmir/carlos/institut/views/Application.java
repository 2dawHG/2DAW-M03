/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cat.iesjoaquimmir.carlos.institut.views;

import cat.iesjoaquimmir.carlos.institut.model.businesslayer.entities.Alumne;
import cat.iesjoaquimmir.carlos.institut.model.persistence.daos.contracts.AlumneDAO;
import cat.iesjoaquimmir.carlos.institut.model.persistence.daos.impl.jdbc.AlumneMySQLDAO;
import cat.iesjoaquimmir.carlos.institut.model.persistence.exception.PersistenceException;
import java.util.List;
import java.util.Scanner;

/**
 *
 * @author daw2017
 */
public class Application {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws PersistenceException {
        Scanner input = new Scanner(System.in);
        int num;
        do {    
            System.out.printf("1-SELECT Alumne%n2-SELECT * Alumnes%n3-INSERT Alumne%n4-UPDATE Alumne%n5-Surt del programa%n%nEscull la opció: ");
            num = input.nextInt();

            switch (num) {
                case 1:
                    selectAlumne();
                    break;
                case 2:
                    selectAllAlumnes();
                    break;
                case 3:
                    insertAlumne();
                    break;
                case 4:
                    updAlumne();
                    break;
            }
        } while(num != 5);
        System.out.printf("%nPassi bon dia vosté!");
    }
    
    public static void selectAlumne() throws PersistenceException {
        Scanner input = new Scanner(System.in);
        AlumneDAO alumneDAO = new AlumneMySQLDAO();

        System.out.printf("Donem el ID del alumne que vols mostrar: ");
        long id = input.nextLong();
        
        try {
            Alumne alumne = alumneDAO.getAlumneById(id);
            if (alumne != null) {
                System.out.println(alumne.toString());
            }
        } catch (PersistenceException e) {
            e.printStackTrace();
        }
    }
    
    public static void selectAllAlumnes() throws PersistenceException {
        AlumneDAO alumneDAO = new AlumneMySQLDAO();
        
        try {
            List<Alumne> alumnes = alumneDAO.getAlumnes();
            for (Alumne alumne : alumnes) {
                System.out.println(alumne.toString());
            }
        } catch (PersistenceException ex) {
            ex.printStackTrace();
        }
    }
    
    public static void insertAlumne() throws PersistenceException {
        Scanner input = new Scanner(System.in);
        AlumneDAO alumneDAO = new AlumneMySQLDAO(); 
        
        System.out.printf("Donem el teu nom: ");
        String nom = input.next();
        System.out.printf("Donem el primer cognom: ");
        String cognom1 = input.next();
        System.out.printf("Donem el segon cognom: ");
        String cognom2 = input.next();
        System.out.printf("Donem el DNI: ");
        String dni = input.next();
        
        Alumne alumne = new Alumne(nom, cognom1, cognom2, dni);
        
        try {
            alumneDAO.saveAlumne(alumne);      
        } catch (PersistenceException e) {
            e.printStackTrace();

	}
    }
        
        public static void updAlumne() throws PersistenceException {
            Scanner input = new Scanner(System.in);
        AlumneDAO alumneDAO = new AlumneMySQLDAO();
        
        try {
            List<Alumne> alumnes = alumneDAO.getAlumnes();
            for (Alumne alumne : alumnes) {
                System.out.println(alumne.toString());
            }
        } catch (PersistenceException ex) {
            ex.printStackTrace();
        }

        System.out.printf("Donem el ID del color que vols modificar: ");
        long id = input.nextLong();
        
        Alumne alumne = alumneDAO.getAlumneById(id);
        
        System.out.printf("Donem el nom: ");
        String nom = input.next();
        System.out.printf("Donem el primer cognom: ");
        String cognom1 = input.next();
        System.out.printf("Donem el segon cognom: ");
        String cognom2 = input.next();
        System.out.printf("Donem el DNI: ");
        String dni = input.next();
        
        alumne.setNom(nom);
        alumne.setCognom1(cognom1);
        alumne.setCognom2(cognom2);
        alumne.setDni(dni);

        
        try {
            alumneDAO.updateAlumne(alumne);      
        } catch (PersistenceException e) {
            e.printStackTrace();

	}

    }
   
}
