/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cat.iesjoaquimmir.carlos.institut.model.persistence.daos.impl.jdbc;

import cat.iesjoaquimmir.carlos.institut.model.businesslayer.entities.Alumne;
import cat.iesjoaquimmir.carlos.institut.model.persistence.daos.contracts.AlumneDAO;
import cat.iesjoaquimmir.carlos.institut.model.persistence.exception.PersistenceException;
import cat.iesjoaquimmir.carlos.institut.model.persistence.utilities.JDBCUtils;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author daw2017
 */
public class AlumneMySQLDAO implements AlumneDAO {
    
    @Override
    public Alumne getAlumneById(long id) throws PersistenceException {
    
        Alumne alumne = null;
        Connection conn = null;
        //PreparedStatement sql = null;
        CallableStatement sql = null;
        
        try {
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/Institut", "root", "root");
            // sql =  conn.prepareStatement("SELECT id, nom, cognom1, cognom2, dni FROM Alumnes where id=?");
            sql = conn.prepareCall("CALL getAlumneById(?)");
                sql.setLong(1, id);
                try(ResultSet reader = sql.executeQuery();) {
                    if(reader.next()) {
                        alumne = JDBCUtils.getAlumne(reader);
                    }
                }
            } catch (SQLException e) {
                throw new PersistenceException(e.getErrorCode());
        } finally {
            try {
                if(sql!=null) {
                    sql.close();
                }
                if(conn!=null) {
                    conn.close();
                }
            } catch (SQLException e) {
                throw new PersistenceException(e.getErrorCode());
            }
            return alumne;
        }
    }

    @Override
    public List<Alumne> getAlumnes() throws PersistenceException {
        Alumne alumne = null;
        Connection conn = null;
        //PreparedStatement sql = null;
        CallableStatement sql = null;
        List<Alumne> alumnes = new ArrayList<>();
        
        try {
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/Institut", "root", "root");
            //sql = conn.prepareStatement("SELECT id, nom, cognom1, cognom2, dni FROM Alumnes");
            sql = conn.prepareCall("CALL getAlumnes()");
            try(ResultSet reader = sql.executeQuery();) {
                while (reader.next()) {
                    alumnes.add(JDBCUtils.getAlumne(reader));
                }
            }
        } catch (SQLException e) {
            throw new PersistenceException(e.getErrorCode());
        } finally {
            try {
                if(sql!=null) {
                    sql.close();
                }
                if(conn!=null) {
                    conn.close();
                }
            } catch (SQLException e) {
                throw new PersistenceException(e.getErrorCode());
            }
            return alumnes;
        }
    }

    @Override
    public void saveAlumne(Alumne alumne) throws PersistenceException {
        Connection conn = null;
        //PreparedStatement sql = null;
        CallableStatement sql = null;
        
        try {
           conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/Institut", "root", "root");
           //sql = conn.prepareStatement("INSERT INTO dades (nom, cognom1, cognom2, dni) VALUES (?,?,?,?)");
           sql = conn.prepareCall("CALL saveAlumne(?,?,?,?)");
           
           sql.setString(1, alumne.getNom());
           sql.setString(2, alumne.getCognom1());
           sql.setString(3, alumne.getCognom2());
           sql.setString(4, alumne.getDni());
           
           sql.executeUpdate();
           
        } catch (SQLException e) {
            throw new PersistenceException(e.getErrorCode());
        } finally {
            try {
                if(sql!=null) {
                    sql.close();
                }
                if(conn!=null) {
                    conn.close();
                }
            } catch (SQLException e) {
                throw new PersistenceException(e.getErrorCode());
            }
        }
    }

    @Override
    public void updateAlumne(Alumne alumne) throws PersistenceException {
        Connection conn = null;
        //PreparedStatement sql = null;
        CallableStatement sql = null;
        
        try {
           conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/Institut", "root", "root");
           //sql = conn.prepareStatement("UPDATE colors SET alpha=?, red=?, green=?, blue=? WHERE id = ?");
           sql = conn.prepareCall("CALL updateAlumne(?,?,?,?,?)");
           
           sql.setString(1, alumne.getNom());
           sql.setString(2, alumne.getCognom1());
           sql.setString(3, alumne.getCognom2());
           sql.setString(4, alumne.getDni());
           sql.setLong(5, alumne.getId());
           
           sql.executeUpdate();
           
        } catch (SQLException e) {
            throw new PersistenceException(e.getErrorCode());
        } finally {
            try {
                if(sql!=null) {
                    sql.close();
                }
                if(conn!=null) {
                    conn.close();
                }
            } catch (SQLException e) {
                throw new PersistenceException(e.getErrorCode());
            }
        }
    }
}