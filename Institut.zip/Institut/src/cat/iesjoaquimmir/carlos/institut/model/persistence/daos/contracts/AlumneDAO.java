/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cat.iesjoaquimmir.carlos.institut.model.persistence.daos.contracts;

import cat.iesjoaquimmir.carlos.institut.model.businesslayer.entities.Alumne;
import cat.iesjoaquimmir.carlos.institut.model.persistence.exception.PersistenceException;
import java.util.List;

/**
 *
 * @author daw2017
 */
public interface AlumneDAO {
    
    public abstract Alumne getAlumneById(long id) throws PersistenceException;
    public abstract List<Alumne> getAlumnes() throws PersistenceException;
    public abstract void saveAlumne(Alumne alumne) throws PersistenceException;
    public abstract void updateAlumne(Alumne alumne) throws PersistenceException;
    
}
