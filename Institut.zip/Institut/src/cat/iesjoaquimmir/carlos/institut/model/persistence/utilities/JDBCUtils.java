/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cat.iesjoaquimmir.carlos.institut.model.persistence.utilities;

import cat.iesjoaquimmir.carlos.institut.model.businesslayer.entities.Alumne;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 *
 * @author daw2017
 */
public class JDBCUtils {
    private JDBCUtils() {
        
    }
    
    public static Alumne getAlumne(ResultSet reader) throws SQLException {
        Alumne alumne = new Alumne( reader.getString("nom"),
                                    reader.getString("cognom1"),
                                    reader.getString("cognom2"),
                                    reader.getString("dni"));
        alumne.setId(reader.getLong("id"));
        return alumne;
    }
}
